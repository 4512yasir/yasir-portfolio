// mobile menu
const burgericon = document.querySelector('#burger');
const navbarmenu = document.querySelector('#nav-links');
burgericon.addEventListener('clik' , ()=> {
     navbarmenu.classList.toggle('is-active');
});